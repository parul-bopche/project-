#![no_std]
use soroban_sdk::{contract, contractimpl, contracttype, Env, Symbol, String, Address, symbol_short};

#[contracttype]
#[derive(Clone)]
pub struct Certificate {
    pub certificate_id: String,
    pub recipient: Address,
    pub course_name: String,
    pub issue_date: u64,
    pub validity: bool,
}

#[contracttype]
pub enum CertificateBook {
    Cert(String), // (CertificateID)
}

const CERTIFICATE_COUNT: Symbol = symbol_short!("CERT_CONT");

#[contract]
pub struct DigitalCertificateVerifier;

#[contractimpl]
impl DigitalCertificateVerifier {
    pub fn issue_certificate(env: Env, recipient: Address, course_name: String, certificate_id: String) {
        let mut count = env.storage().instance().get(&CERTIFICATE_COUNT).unwrap_or(0);
        count += 1;

        let certificate = Certificate {
            certificate_id: certificate_id.clone(),
            recipient: recipient.clone(),
            course_name: course_name.clone(),
            issue_date: env.ledger().timestamp(),
            validity: true,
        };

        env.storage().instance().set(&CertificateBook::Cert(certificate_id), &certificate);
        env.storage().instance().set(&CERTIFICATE_COUNT, &count);
    }

    pub fn revoke_certificate(env: Env, certificate_id: String) {
        let mut certificate: Certificate = env.storage().instance().get(&CertificateBook::Cert(certificate_id.clone())).expect("Certificate not found");
        
        certificate.validity = false;

        env.storage().instance().set(&CertificateBook::Cert(certificate_id), &certificate);
    }

}
